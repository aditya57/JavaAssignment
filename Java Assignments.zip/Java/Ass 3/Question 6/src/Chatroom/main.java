package Chatroom;
import java.util.ArrayList;

public class main {
	public static void main(String[] args) {
		ArrayList<String> user= new ArrayList<String>();
		user.add("Sunita");

		}

}
