package Company;
import java.util.*;

public class Emp {
	private String name;
    public Emp(String name) {
        this.name = name;
    }
    @Override
    public String toString() {
        return "Emp{" +
                "name='" + name + '\'' +
                '}';
    }

}
