package supershape;

public class Shape {
	public static void main(String[] args) {
		Line l=new Line();
	      l.draw();
	      Rectangle r=new Rectangle();
	      r.draw();
	      Cube c=new Cube();
	      c.draw();
	}

}
