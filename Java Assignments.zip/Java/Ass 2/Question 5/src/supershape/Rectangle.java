package supershape;

public class Rectangle extends Shape{
	void draw()
	{
		System.out.println(" This is a rectangle!");
	}
}
