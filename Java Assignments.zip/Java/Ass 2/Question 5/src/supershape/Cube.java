package supershape;

public class Cube extends Shape {
	void draw()
	{
		System.out.println(" This is cube shape!");
	}

}
