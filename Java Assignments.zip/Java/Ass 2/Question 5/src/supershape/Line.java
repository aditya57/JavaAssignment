package supershape;

public class Line extends Shape {
	void draw()
	{
		System.out.println(" This is a line!");
	}


}
