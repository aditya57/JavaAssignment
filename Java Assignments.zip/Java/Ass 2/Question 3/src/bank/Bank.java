package bank;
public class Bank {
	public float amount() {
		return 0;
	}
}
