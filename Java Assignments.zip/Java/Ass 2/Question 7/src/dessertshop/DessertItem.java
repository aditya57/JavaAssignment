package dessertshop;

public abstract class DessertItem {
	public abstract float getCost();
}
