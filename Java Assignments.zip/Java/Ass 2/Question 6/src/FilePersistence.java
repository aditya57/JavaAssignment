public class FilePersistence extends Persistence {
	@Override
	void presist() {
		System.out.println("This is file Persistence");
	}
}