
public class DatabasePersistence extends Persistence {
	@Override
	void presist() {
		System.out.println("This is database Persistence");
	}
}
