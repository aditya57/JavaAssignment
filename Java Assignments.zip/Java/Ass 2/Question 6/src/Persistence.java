import java.util.Scanner;
public abstract class Persistence {
	Scanner input= new Scanner(System.in);
	abstract void presist();
}
