
public final abstract class  abstract4 {
	   public void sample() {}
}
