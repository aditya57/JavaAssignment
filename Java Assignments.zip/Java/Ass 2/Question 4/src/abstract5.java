abstract class abstract5 {
	   public void display() {
		      System.out.println("This is a method of abstract class");
		   }
}
