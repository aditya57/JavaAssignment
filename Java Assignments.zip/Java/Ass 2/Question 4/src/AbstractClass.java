
public class AbstractClass extends abstract5{
	public static void main(String args[]) {
		 new AbstractClass().display();
		}
}
