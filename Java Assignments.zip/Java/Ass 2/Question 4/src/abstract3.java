
abstract class abstract3 {
	   private static abstract void display();
}
